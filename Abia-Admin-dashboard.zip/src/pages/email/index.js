import React from "react";
import List from "./List";

const index = () => {
  return (
    <div>
      <List />
    </div>
  );
};

export default index;
